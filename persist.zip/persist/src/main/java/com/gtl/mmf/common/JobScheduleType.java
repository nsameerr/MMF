/**
 * 
 */
package com.gtl.mmf.common;

/**
 * @author 08237
 *
 */
public enum JobScheduleType {
	STAGED,
	INPROGRESS,
	COMPLETED,
	ERROR
}
