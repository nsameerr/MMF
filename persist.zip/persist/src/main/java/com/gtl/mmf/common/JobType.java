/**
 * 
 */
package com.gtl.mmf.common;

/**
 * @author 08237
 *
 */
public enum JobType {
	TXN,
	CASH,
        TXN_DUMMY,
        CASH_DUMMY,
        PAYINOUT,
        POSITION
}
