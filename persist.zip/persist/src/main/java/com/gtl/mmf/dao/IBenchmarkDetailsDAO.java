/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gtl.mmf.dao;

import com.gtl.mmf.entity.BenchmarkPerformanceTb;

/**
 *
 * @author 07958
 */
public interface IBenchmarkDetailsDAO {

    public int insertNewBenchmarkDetails(BenchmarkPerformanceTb benchmarkPerformanceTb);
}
