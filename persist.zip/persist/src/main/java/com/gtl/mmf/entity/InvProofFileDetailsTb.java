package com.gtl.mmf.entity;

public class InvProofFileDetailsTb {
	int id;
	String email;
	String bankFilePath;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBankFilePath() {
		return bankFilePath;
	}
	public void setBankFilePath(String bankFilePath) {
		this.bankFilePath = bankFilePath;
	}
	
}
