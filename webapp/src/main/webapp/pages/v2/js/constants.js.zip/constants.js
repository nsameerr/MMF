//BaseURL
_gc_url_baseUrl = 'http://localhost:8080/';



//riskProfile
_gc_url_rp_post_riskProfile = ''
_gc_url_rp_redirect_riskProfileoutput ='riskProfileOutput.html';


//Financial Planner Output
//FinancialPlannerOutput.... editRiskScore, editSavingsRate, editAllocationToMMF, editRetirmentAge, editAssumptions, editLifeGoals,  

//GET
_gc_url_fpo_get_assetExpenditureChart = 'data.json';

_gc_url_fpo_post_editRiskScore = _gc_url_baseUrl + '';
_gc_url_fpo_post_editSavingsRate = _gc_url_baseUrl + '';
_gc_url_fpo_post_editAllocationToMMF = _gc_url_baseUrl + '';
_gc_url_fpo_post_editRetirmentAge = _gc_url_baseUrl + '';
_gc_url_fpo_post_editAssumptions = _gc_url_baseUrl + '';
_gc_url_fpo_post_editLifeGoals = _gc_url_baseUrl + '';

_gc_url_fpo_redirect_saveYourResponse = _gc_url_baseUrl + '';
_gc_url_fpo_redirect_saveAndSubmit = _gc_url_baseUrl + '';



//Userprofile
_gc_up_post_submit = ''
	

//Investor Registration
_gc_url_ir_post_autoSave = _gc_url_baseUrl + 'service/mmfresource/autoSaveInvCompleteService';
_gc_url_ir_post_finalSave = _gc_url_baseUrl + '';


//AccountStatus
_gc_url_as_post_getStatus = 'accountStatus.json';