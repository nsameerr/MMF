@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.marketsummary.git.com/")
package com.git.marketsummary.ws;
