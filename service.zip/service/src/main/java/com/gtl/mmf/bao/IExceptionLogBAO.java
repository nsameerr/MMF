/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * created by 07662
 */
package com.gtl.mmf.bao;

public interface IExceptionLogBAO {

    public void logErrorDb(String errorMessage, String exception);

}
