/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gtl.mmf.service.vo;

/**
 *
 * @author trainee12
 */
public class RegistrationDataProcessingVo {
    
    RegistrationVo registrationVo;
    MandateVo mandateVo;

    public RegistrationVo getRegistrationVo() {
        return registrationVo;
    }

    public void setRegistrationVo(RegistrationVo registrationVo) {
        this.registrationVo = registrationVo;
    }

    public MandateVo getMandateVo() {
        return mandateVo;
    }

    public void setMandateVo(MandateVo mandateVo) {
        this.mandateVo = mandateVo;
    }
    
    
  
    
}
