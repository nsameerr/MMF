package com.gtl.mmf.bao;

public interface IPortfolioSearchBAO {

	public String getDefaultPortfolioSearchResult();
}
