/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gtl.mmf.service.vo;

import java.io.Serializable;

/**
 *
 * @author 09860
 */
public class TempInvVo implements Serializable {

    private String regId;
    private String email;
    private String firstname;
    private String middlename;
    private String lastname;
    private String fatherSpouse;
    private String dob;
    private String nationality;
    private String status;
    private String gender;
    private String mstatus;
    private String uid;
    private String pan;
    private String caddressline1;
    private String caddressline2;
    private String clandmark;
    private String cpincode;
    private String country;
    private String cstate;
    private String ccity;
    private String cproof;
    private String cvalidity;
    private String permenentAddress;
    private String paddressline1;
    private String paddressline2;
    private String plandmark;
    private String ppin;
    private String pcountry;
    private String pstate;
    private String pcity;
    private String pproof;
    private String pvalidity;
    private String mobile;
    private String histd;
    private String hstd;
    private String htelephone;
    private String risd;
    private String rstd;
    private String rtelephone;
    private String fisd;
    private String fstd;
    private String ftelphone;
    private String bankname;
//    private String branch;
    private String accountType;
    private String accno;
    private String reAccno;
    private String bifsc;
    private String bmicr;
    private String baddressline1;
    private String baddressline2;
    private String blandmark;
    private String bpincode;
    private String bcountry;
    private String bstate;
    private String bcity;
    private String cCityOther;
    private String pCityOther;
    private String bnkCityOther;

    private String panFilePath;
    private String corsFilePath;
    private String prmntFilePath;

    public String getRegId() {
        return regId;
    }

    public void setRegId(String regId) {
        this.regId = regId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getMiddlename() {
        return middlename;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFatherSpouse() {
        return fatherSpouse;
    }

    public void setFatherSpouse(String fatherSpouse) {
        this.fatherSpouse = fatherSpouse;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMstatus() {
        return mstatus;
    }

    public void setMstatus(String mstatus) {
        this.mstatus = mstatus;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getCaddressline1() {
        return caddressline1;
    }

    public void setCaddressline1(String caddressline1) {
        this.caddressline1 = caddressline1;
    }

    public String getCaddressline2() {
        return caddressline2;
    }

    public void setCaddressline2(String caddressline2) {
        this.caddressline2 = caddressline2;
    }

    public String getClandmark() {
        return clandmark;
    }

    public void setClandmark(String clandmark) {
        this.clandmark = clandmark;
    }

    public String getCpincode() {
        return cpincode;
    }

    public void setCpincode(String cpincode) {
        this.cpincode = cpincode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCstate() {
        return cstate;
    }

    public void setCstate(String cstate) {
        this.cstate = cstate;
    }

    public String getCcity() {
        return ccity;
    }

    public void setCcity(String ccity) {
        this.ccity = ccity;
    }

    public String getCproof() {
        return cproof;
    }

    public void setCproof(String cproof) {
        this.cproof = cproof;
    }

    public String getCvalidity() {
        return cvalidity;
    }

    public void setCvalidity(String cvalidity) {
        this.cvalidity = cvalidity;
    }

    public String getPermenentAddress() {
        return permenentAddress;
    }

    public void setPermenentAddress(String permenentAddress) {
        this.permenentAddress = permenentAddress;
    }

    public String getPaddressline1() {
        return paddressline1;
    }

    public void setPaddressline1(String paddressline1) {
        this.paddressline1 = paddressline1;
    }

    public String getPaddressline2() {
        return paddressline2;
    }

    public void setPaddressline2(String paddressline2) {
        this.paddressline2 = paddressline2;
    }

    public String getPlandmark() {
        return plandmark;
    }

    public void setPlandmark(String plandmark) {
        this.plandmark = plandmark;
    }

    public String getPpin() {
        return ppin;
    }

    public void setPpin(String ppin) {
        this.ppin = ppin;
    }

    public String getPcountry() {
        return pcountry;
    }

    public void setPcountry(String pcountry) {
        this.pcountry = pcountry;
    }

    public String getPstate() {
        return pstate;
    }

    public void setPstate(String pstate) {
        this.pstate = pstate;
    }

    public String getPcity() {
        return pcity;
    }

    public void setPcity(String pcity) {
        this.pcity = pcity;
    }

    public String getPproof() {
        return pproof;
    }

    public void setPproof(String pproof) {
        this.pproof = pproof;
    }

    public String getPvalidity() {
        return pvalidity;
    }

    public void setPvalidity(String pvalidity) {
        this.pvalidity = pvalidity;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getHistd() {
        return histd;
    }

    public void setHistd(String histd) {
        this.histd = histd;
    }

    public String getHstd() {
        return hstd;
    }

    public void setHstd(String hstd) {
        this.hstd = hstd;
    }

    public String getHtelephone() {
        return htelephone;
    }

    public void setHtelephone(String htelephone) {
        this.htelephone = htelephone;
    }

    public String getRisd() {
        return risd;
    }

    public void setRisd(String risd) {
        this.risd = risd;
    }

    public String getRstd() {
        return rstd;
    }

    public void setRstd(String rstd) {
        this.rstd = rstd;
    }

    public String getRtelephone() {
        return rtelephone;
    }

    public void setRtelephone(String rtelephone) {
        this.rtelephone = rtelephone;
    }

    public String getFisd() {
        return fisd;
    }

    public void setFisd(String fisd) {
        this.fisd = fisd;
    }

    public String getFstd() {
        return fstd;
    }

    public void setFstd(String fstd) {
        this.fstd = fstd;
    }

    public String getFtelphone() {
        return ftelphone;
    }

    public void setFtelphone(String ftelphone) {
        this.ftelphone = ftelphone;
    }

    public String getBankname() {
        return bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccno() {
        return accno;
    }

    public void setAccno(String accno) {
        this.accno = accno;
    }

    public String getReAccno() {
        return reAccno;
    }

    public void setReAccno(String reAccno) {
        this.reAccno = reAccno;
    }

    public String getBifsc() {
        return bifsc;
    }

    public void setBifsc(String bifsc) {
        this.bifsc = bifsc;
    }

    public String getBmicr() {
        return bmicr;
    }

    public void setBmicr(String bmicr) {
        this.bmicr = bmicr;
    }

    public String getBaddressline1() {
        return baddressline1;
    }

    public void setBaddressline1(String baddressline1) {
        this.baddressline1 = baddressline1;
    }

    public String getBaddressline2() {
        return baddressline2;
    }

    public void setBaddressline2(String baddressline2) {
        this.baddressline2 = baddressline2;
    }

    public String getBlandmark() {
        return blandmark;
    }

    public void setBlandmark(String blandmark) {
        this.blandmark = blandmark;
    }

    public String getBpincode() {
        return bpincode;
    }

    public void setBpincode(String bpincode) {
        this.bpincode = bpincode;
    }

    public String getBcountry() {
        return bcountry;
    }

    public void setBcountry(String bcountry) {
        this.bcountry = bcountry;
    }

    public String getBstate() {
        return bstate;
    }

    public void setBstate(String bstate) {
        this.bstate = bstate;
    }

    public String getBcity() {
        return bcity;
    }

    public void setBcity(String bcity) {
        this.bcity = bcity;
    }

    public String getcCityOther() {
        return cCityOther;
    }

    public void setcCityOther(String cCityOther) {
        this.cCityOther = cCityOther;
    }

    public String getpCityOther() {
        return pCityOther;
    }

    public void setpCityOther(String pCityOther) {
        this.pCityOther = pCityOther;
    }

    public String getBnkCityOther() {
        return bnkCityOther;
    }

    public void setBnkCityOther(String bnkCityOther) {
        this.bnkCityOther = bnkCityOther;
    }

    public String getPanFilePath() {
        return panFilePath;
    }

    public void setPanFilePath(String panFilePath) {
        this.panFilePath = panFilePath;
    }

    public String getCorsFilePath() {
        return corsFilePath;
    }

    public void setCorsFilePath(String corsFilePath) {
        this.corsFilePath = corsFilePath;
    }

    public String getPrmntFilePath() {
        return prmntFilePath;
    }

    public void setPrmntFilePath(String prmntFilePath) {
        this.prmntFilePath = prmntFilePath;
    }

//    public String getBranch() {
//        return branch;
//    }
//
//    public void setBranch(String branch) {
//        this.branch = branch;
//    }

}
