package com.gtl.mmf.service.vo.riskprofile;

public class RiskProfileResponse {
	private int questionId;
    private int answerId;
	
	public RiskProfileResponse() {
		// TODO Auto-generated constructor stub
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public int getAnswerId() {
		return answerId;
	}
	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}
	
}
