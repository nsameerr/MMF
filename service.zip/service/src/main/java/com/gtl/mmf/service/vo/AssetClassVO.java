/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gtl.mmf.service.vo;

/**
 *
 * @author 07958
 */
public class AssetClassVO {

    private Integer assetId;
    private String assetName;
    private String assetColor;

    public Integer getAssetId() {
        return assetId;
    }

    public void setAssetId(Integer assetId) {
        this.assetId = assetId;
    }

    public String getAssetName() {
        return assetName;
    }

    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }

    public String getAssetColor() {
        return assetColor;
    }

    public void setAssetColor(String assetColor) {
        this.assetColor = assetColor;
    }
}
