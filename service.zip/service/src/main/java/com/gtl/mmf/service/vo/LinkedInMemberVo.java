/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gtl.mmf.service.vo;

/**
 *
 * @author trainee3
 */
public class LinkedInMemberVo {

    private String linkedinMemberId;

    public String getLinkedinMemberId() {
        return linkedinMemberId;
    }

    public void setLinkedinMemberId(String linkedinMemberId) {
        this.linkedinMemberId = linkedinMemberId;
    }

}
