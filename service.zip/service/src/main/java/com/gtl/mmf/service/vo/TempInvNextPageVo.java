/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gtl.mmf.service.vo;

import java.io.Serializable;

/**
 *
 * @author 09860
 */
public class TempInvNextPageVo implements Serializable {

    private String openAccountType;
    private String dp;
    private String tradingtAccount;
    private String dematAccount;
    private String smsFacility;
    private String fstHldrOccup;
    private String fstHldrOrg;
    private String fstHldrDesig;
    private String fstHldrIncome;
    private String fstHldrNet;
    private String fstHldrAmt;
    private String pep;
    private String rpep;
    private boolean scndHldrExist;
    private String scndHldrName;
    private String scndHldrOccup;
    private String scndHldrOrg;
    private String scndHldrDesig;
    private String scndHldrSms;
    private String scndHldrIncome;
    private String scndHldrNet;
    private String scndHldrAmt;
    private String scndPep;
    private String scndRpep;
    private String instrn1;
    private String instrn2;
    private String instrn3;
    private String instrn4;
    private String instrn5;
    private String depoPartcpnt;
    private String deponame;
    private String beneficiary;
    private String dpId;
    private String docEvdnc;
    private String other;
    private String experience;
    private String contractNote;
    private String intrntTrading;
    private String alert;
    private String relationship;
    private String panAddtnl;
    private String otherInformation;
    private boolean nomineeExist;
    private String nameNominee;
    private String nomineeRelation;
    private String nomineeDob;
    private String nomineeProof;
    private String nomineAadhar;
    private String nominePan;
    private String nomineeAdrs1;
    private String nomineeAdrs2;
    private String nomineeLnd;
    private String nomineePincode;
    private String nomCountry;
    private String nomState;
    private String nomCity;
    private String noisd;
    private String nostd;
    private String notelephone;
    private String nrisd;
    private String nrstd;
    private String nRtelephone;
    private String nfisd;
    private String nfstd;
    private String nomineeFax;
    private String nomMobile;
    private String nomEmail;
    private boolean  minorExist;
    private String minorGuard;
    private String mnrReltn;
    private String mnrDob;
    private String mnrProof;
    private String mnrPan;
    private String mnrAadhar;
    private String mnrAdrs1;
    private String mnrAdrs2;
    private String mnrLnd;
    private String mnrCountry;
    private String mnrState;
    private String mnrCity;
    private String mnrPincode;
    private String moisd;
    private String mostd;
    private String motel;
    private String mrisd;
    private String mrstd;
    private String mrtel;
    private String mfisd;
    private String mfstd;
    private String minorfax;
    private String mnrMob;
    private String mnrEmail;
    private String nomCityOther;
    private String mnrCityOther;
    private String docFilePath;
    private String usNational;
    private String usResident;
    private String usBorn;
    private String usAddress;
    private String usTelephone;
    private String usStandingInstruction;
    private String usPoa;
    private String usMailAddress;
    private String individualTaxIdntfcnNmbr;
    private String secondHldrPan;
    private String secondHldrDependentRelation;
    private String secondHldrDependentUsed;
    private String firstHldrDependentUsed;

    public String getOpenAccountType() {
        return openAccountType;
    }

    public void setOpenAccountType(String openAccountType) {
        this.openAccountType = openAccountType;
    }

    public String getDp() {
        return dp;
    }

    public void setDp(String dp) {
        this.dp = dp;
    }

    public String getTradingtAccount() {
        return tradingtAccount;
    }

    public void setTradingtAccount(String tradingtAccount) {
        this.tradingtAccount = tradingtAccount;
    }

    public String getDematAccount() {
        return dematAccount;
    }

    public void setDematAccount(String dematAccount) {
        this.dematAccount = dematAccount;
    }

    public String getSmsFacility() {
        return smsFacility;
    }

    public void setSmsFacility(String smsFacility) {
        this.smsFacility = smsFacility;
    }

    public String getFstHldrOccup() {
        return fstHldrOccup;
    }

    public void setFstHldrOccup(String fstHldrOccup) {
        this.fstHldrOccup = fstHldrOccup;
    }

    public String getFstHldrOrg() {
        return fstHldrOrg;
    }

    public void setFstHldrOrg(String fstHldrOrg) {
        this.fstHldrOrg = fstHldrOrg;
    }

    public String getFstHldrDesig() {
        return fstHldrDesig;
    }

    public void setFstHldrDesig(String fstHldrDesig) {
        this.fstHldrDesig = fstHldrDesig;
    }

    public String getFstHldrIncome() {
        return fstHldrIncome;
    }

    public void setFstHldrIncome(String fstHldrIncome) {
        this.fstHldrIncome = fstHldrIncome;
    }

    public String getFstHldrNet() {
        return fstHldrNet;
    }

    public void setFstHldrNet(String fstHldrNet) {
        this.fstHldrNet = fstHldrNet;
    }

    public String getFstHldrAmt() {
        return fstHldrAmt;
    }

    public void setFstHldrAmt(String fstHldrAmt) {
        this.fstHldrAmt = fstHldrAmt;
    }

    public String getPep() {
        return pep;
    }

    public void setPep(String pep) {
        this.pep = pep;
    }

    public String getRpep() {
        return rpep;
    }

    public void setRpep(String rpep) {
        this.rpep = rpep;
    }

    public String getScndHldrName() {
        return scndHldrName;
    }

    public void setScndHldrName(String scndHldrName) {
        this.scndHldrName = scndHldrName;
    }

    public String getScndHldrOccup() {
        return scndHldrOccup;
    }

    public void setScndHldrOccup(String scndHldrOccup) {
        this.scndHldrOccup = scndHldrOccup;
    }

    public String getScndHldrOrg() {
        return scndHldrOrg;
    }

    public void setScndHldrOrg(String scndHldrOrg) {
        this.scndHldrOrg = scndHldrOrg;
    }

    public String getScndHldrDesig() {
        return scndHldrDesig;
    }

    public void setScndHldrDesig(String scndHldrDesig) {
        this.scndHldrDesig = scndHldrDesig;
    }

    public String getScndHldrSms() {
        return scndHldrSms;
    }

    public void setScndHldrSms(String scndHldrSms) {
        this.scndHldrSms = scndHldrSms;
    }

    public String getScndHldrIncome() {
        return scndHldrIncome;
    }

    public void setScndHldrIncome(String scndHldrIncome) {
        this.scndHldrIncome = scndHldrIncome;
    }

    public String getScndHldrNet() {
        return scndHldrNet;
    }

    public void setScndHldrNet(String scndHldrNet) {
        this.scndHldrNet = scndHldrNet;
    }

    public String getScndHldrAmt() {
        return scndHldrAmt;
    }

    public void setScndHldrAmt(String scndHldrAmt) {
        this.scndHldrAmt = scndHldrAmt;
    }

    public String getScndPep() {
        return scndPep;
    }

    public void setScndPep(String scndPep) {
        this.scndPep = scndPep;
    }

    public String getScndRpep() {
        return scndRpep;
    }

    public void setScndRpep(String scndRpep) {
        this.scndRpep = scndRpep;
    }

    public String getInstrn1() {
        return instrn1;
    }

    public void setInstrn1(String instrn1) {
        this.instrn1 = instrn1;
    }

    public String getInstrn2() {
        return instrn2;
    }

    public void setInstrn2(String instrn2) {
        this.instrn2 = instrn2;
    }

    public String getInstrn3() {
        return instrn3;
    }

    public void setInstrn3(String instrn3) {
        this.instrn3 = instrn3;
    }

    public String getInstrn4() {
        return instrn4;
    }

    public void setInstrn4(String instrn4) {
        this.instrn4 = instrn4;
    }

    public String getInstrn5() {
        return instrn5;
    }

    public void setInstrn5(String instrn5) {
        this.instrn5 = instrn5;
    }

    public String getDepoPartcpnt() {
        return depoPartcpnt;
    }

    public void setDepoPartcpnt(String depoPartcpnt) {
        this.depoPartcpnt = depoPartcpnt;
    }

    public String getDeponame() {
        return deponame;
    }

    public void setDeponame(String deponame) {
        this.deponame = deponame;
    }

    public String getBeneficiary() {
        return beneficiary;
    }

    public void setBeneficiary(String beneficiary) {
        this.beneficiary = beneficiary;
    }

    public String getDpId() {
        return dpId;
    }

    public void setDpId(String dpId) {
        this.dpId = dpId;
    }

    public String getDocEvdnc() {
        return docEvdnc;
    }

    public void setDocEvdnc(String docEvdnc) {
        this.docEvdnc = docEvdnc;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getContractNote() {
        return contractNote;
    }

    public void setContractNote(String contractNote) {
        this.contractNote = contractNote;
    }

    public String getIntrntTrading() {
        return intrntTrading;
    }

    public void setIntrntTrading(String intrntTrading) {
        this.intrntTrading = intrntTrading;
    }

    public String getAlert() {
        return alert;
    }

    public void setAlert(String alert) {
        this.alert = alert;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getPanAddtnl() {
        return panAddtnl;
    }

    public void setPanAddtnl(String panAddtnl) {
        this.panAddtnl = panAddtnl;
    }

    public String getOtherInformation() {
        return otherInformation;
    }

    public void setOtherInformation(String otherInformation) {
        this.otherInformation = otherInformation;
    }

    public String getNameNominee() {
        return nameNominee;
    }

    public void setNameNominee(String nameNominee) {
        this.nameNominee = nameNominee;
    }

    public String getNomineeRelation() {
        return nomineeRelation;
    }

    public void setNomineeRelation(String nomineeRelation) {
        this.nomineeRelation = nomineeRelation;
    }

    public String getNomineeDob() {
        return nomineeDob;
    }

    public void setNomineeDob(String nomineeDob) {
        this.nomineeDob = nomineeDob;
    }

    public String getNominePan() {
        return nominePan;
    }

    public void setNominePan(String nominePan) {
        this.nominePan = nominePan;
    }

    public String getNomineeAdrs1() {
        return nomineeAdrs1;
    }

    public void setNomineeAdrs1(String nomineeAdrs1) {
        this.nomineeAdrs1 = nomineeAdrs1;
    }

    public String getNomineeAdrs2() {
        return nomineeAdrs2;
    }

    public void setNomineeAdrs2(String nomineeAdrs2) {
        this.nomineeAdrs2 = nomineeAdrs2;
    }

    public String getNomineeLnd() {
        return nomineeLnd;
    }

    public void setNomineeLnd(String nomineeLnd) {
        this.nomineeLnd = nomineeLnd;
    }

    public String getNomineePincode() {
        return nomineePincode;
    }

    public void setNomineePincode(String nomineePincode) {
        this.nomineePincode = nomineePincode;
    }

    public String getNomCountry() {
        return nomCountry;
    }

    public void setNomCountry(String nomCountry) {
        this.nomCountry = nomCountry;
    }

    public String getNomState() {
        return nomState;
    }

    public void setNomState(String nomState) {
        this.nomState = nomState;
    }

    public String getNomCity() {
        return nomCity;
    }

    public void setNomCity(String nomCity) {
        this.nomCity = nomCity;
    }

    public String getNoisd() {
        return noisd;
    }

    public void setNoisd(String noisd) {
        this.noisd = noisd;
    }

    public String getNostd() {
        return nostd;
    }

    public void setNostd(String nostd) {
        this.nostd = nostd;
    }

    public String getNotelephone() {
        return notelephone;
    }

    public void setNotelephone(String notelephone) {
        this.notelephone = notelephone;
    }

    public String getNrisd() {
        return nrisd;
    }

    public void setNrisd(String nrisd) {
        this.nrisd = nrisd;
    }

    public String getNrstd() {
        return nrstd;
    }

    public void setNrstd(String nrstd) {
        this.nrstd = nrstd;
    }

    public String getnRtelephone() {
        return nRtelephone;
    }

    public void setnRtelephone(String nRtelephone) {
        this.nRtelephone = nRtelephone;
    }

    public String getNfisd() {
        return nfisd;
    }

    public void setNfisd(String nfisd) {
        this.nfisd = nfisd;
    }

    public String getNfstd() {
        return nfstd;
    }

    public void setNfstd(String nfstd) {
        this.nfstd = nfstd;
    }

    public String getNomineeFax() {
        return nomineeFax;
    }

    public void setNomineeFax(String nomineeFax) {
        this.nomineeFax = nomineeFax;
    }

    public String getNomMobile() {
        return nomMobile;
    }

    public void setNomMobile(String nomMobile) {
        this.nomMobile = nomMobile;
    }

    public String getNomEmail() {
        return nomEmail;
    }

    public void setNomEmail(String nomEmail) {
        this.nomEmail = nomEmail;
    }

    public String getMinorGuard() {
        return minorGuard;
    }

    public void setMinorGuard(String minorGuard) {
        this.minorGuard = minorGuard;
    }

    public String getMnrReltn() {
        return mnrReltn;
    }

    public void setMnrReltn(String mnrReltn) {
        this.mnrReltn = mnrReltn;
    }

    public String getMnrDob() {
        return mnrDob;
    }

    public void setMnrDob(String mnrDob) {
        this.mnrDob = mnrDob;
    }

    public String getMnrAdrs1() {
        return mnrAdrs1;
    }

    public void setMnrAdrs1(String mnrAdrs1) {
        this.mnrAdrs1 = mnrAdrs1;
    }

    public String getMnrAdrs2() {
        return mnrAdrs2;
    }

    public void setMnrAdrs2(String mnrAdrs2) {
        this.mnrAdrs2 = mnrAdrs2;
    }

    public String getMnrLnd() {
        return mnrLnd;
    }

    public void setMnrLnd(String mnrLnd) {
        this.mnrLnd = mnrLnd;
    }

    public String getMnrCountry() {
        return mnrCountry;
    }

    public void setMnrCountry(String mnrCountry) {
        this.mnrCountry = mnrCountry;
    }

    public String getMnrState() {
        return mnrState;
    }

    public void setMnrState(String mnrState) {
        this.mnrState = mnrState;
    }

    public String getMnrCity() {
        return mnrCity;
    }

    public void setMnrCity(String mnrCity) {
        this.mnrCity = mnrCity;
    }

    public String getMnrPincode() {
        return mnrPincode;
    }

    public void setMnrPincode(String mnrPincode) {
        this.mnrPincode = mnrPincode;
    }

    public String getMoisd() {
        return moisd;
    }

    public void setMoisd(String moisd) {
        this.moisd = moisd;
    }

    public String getMostd() {
        return mostd;
    }

    public void setMostd(String mostd) {
        this.mostd = mostd;
    }

    public String getMotel() {
        return motel;
    }

    public void setMotel(String motel) {
        this.motel = motel;
    }

    public String getMrisd() {
        return mrisd;
    }

    public void setMrisd(String mrisd) {
        this.mrisd = mrisd;
    }

    public String getMrstd() {
        return mrstd;
    }

    public void setMrstd(String mrstd) {
        this.mrstd = mrstd;
    }

    public String getMrtel() {
        return mrtel;
    }

    public void setMrtel(String mrtel) {
        this.mrtel = mrtel;
    }

    public String getMfisd() {
        return mfisd;
    }

    public void setMfisd(String mfisd) {
        this.mfisd = mfisd;
    }

    public String getMfstd() {
        return mfstd;
    }

    public void setMfstd(String mfstd) {
        this.mfstd = mfstd;
    }

    public String getMinorfax() {
        return minorfax;
    }

    public void setMinorfax(String minorfax) {
        this.minorfax = minorfax;
    }

    public String getMnrMob() {
        return mnrMob;
    }

    public void setMnrMob(String mnrMob) {
        this.mnrMob = mnrMob;
    }

    public String getMnrEmail() {
        return mnrEmail;
    }

    public void setMnrEmail(String mnrEmail) {
        this.mnrEmail = mnrEmail;
    }

    public boolean isScndHldrExist() {
        return scndHldrExist;
    }

    public void setScndHldrExist(boolean scndHldrExist) {
        this.scndHldrExist = scndHldrExist;
    }

    public boolean isNomineeExist() {
        return nomineeExist;
    }

    public void setNomineeExist(boolean nomineeExist) {
        this.nomineeExist = nomineeExist;
    }

    public boolean isMinorExist() {
        return minorExist;
    }

    public void setMinorExist(boolean minorExist) {
        this.minorExist = minorExist;
    }

    public String getNomCityOther() {
        return nomCityOther;
    }

    public void setNomCityOther(String nomCityOther) {
        this.nomCityOther = nomCityOther;
    }

    public String getMnrCityOther() {
        return mnrCityOther;
    }

    public void setMnrCityOther(String mnrCityOther) {
        this.mnrCityOther = mnrCityOther;
    }

    public String getDocFilePath() {
        return docFilePath;
    }

    public void setDocFilePath(String docFilePath) {
        this.docFilePath = docFilePath;
    }

    public String getUsNational() {
        return usNational;
    }

    public void setUsNational(String usNational) {
        this.usNational = usNational;
    }

    public String getUsResident() {
        return usResident;
    }

    public void setUsResident(String usResident) {
        this.usResident = usResident;
    }

    public String getUsBorn() {
        return usBorn;
    }

    public void setUsBorn(String usBorn) {
        this.usBorn = usBorn;
    }

    public String getUsAddress() {
        return usAddress;
    }

    public void setUsAddress(String usAddress) {
        this.usAddress = usAddress;
    }

    public String getUsTelephone() {
        return usTelephone;
    }

    public void setUsTelephone(String usTelephone) {
        this.usTelephone = usTelephone;
    }

    public String getUsStandingInstruction() {
        return usStandingInstruction;
    }

    public void setUsStandingInstruction(String usStandingInstruction) {
        this.usStandingInstruction = usStandingInstruction;
    }

    public String getUsPoa() {
        return usPoa;
    }

    public void setUsPoa(String usPoa) {
        this.usPoa = usPoa;
    }

    public String getUsMailAddress() {
        return usMailAddress;
    }

    public void setUsMailAddress(String usMailAddress) {
        this.usMailAddress = usMailAddress;
    }

    public String getIndividualTaxIdntfcnNmbr() {
        return individualTaxIdntfcnNmbr;
    }

    public void setIndividualTaxIdntfcnNmbr(String individualTaxIdntfcnNmbr) {
        this.individualTaxIdntfcnNmbr = individualTaxIdntfcnNmbr;
    }

    public String getSecondHldrPan() {
        return secondHldrPan;
    }

    public void setSecondHldrPan(String secondHldrPan) {
        this.secondHldrPan = secondHldrPan;
    }

    public String getSecondHldrDependentRelation() {
        return secondHldrDependentRelation;
    }

    public void setSecondHldrDependentRelation(String secondHldrDependentRelation) {
        this.secondHldrDependentRelation = secondHldrDependentRelation;
    }

    public String getSecondHldrDependentUsed() {
        return secondHldrDependentUsed;
    }

    public void setSecondHldrDependentUsed(String secondHldrDependentUsed) {
        this.secondHldrDependentUsed = secondHldrDependentUsed;
    }

    public String getFirstHldrDependentUsed() {
        return firstHldrDependentUsed;
    }

    public void setFirstHldrDependentUsed(String firstHldrDependentUsed) {
        this.firstHldrDependentUsed = firstHldrDependentUsed;
    }

    public String getNomineeProof() {
        return nomineeProof;
    }

    public void setNomineeProof(String nomineeProof) {
        this.nomineeProof = nomineeProof;
    }

    public String getNomineAadhar() {
        return nomineAadhar;
    }

    public void setNomineAadhar(String nomineAadhar) {
        this.nomineAadhar = nomineAadhar;
    }

    public String getMnrProof() {
        return mnrProof;
    }

    public void setMnrProof(String mnrProof) {
        this.mnrProof = mnrProof;
    }

    public String getMnrPan() {
        return mnrPan;
    }

    public void setMnrPan(String mnrPan) {
        this.mnrPan = mnrPan;
    }

    public String getMnrAadhar() {
        return mnrAadhar;
    }

    public void setMnrAadhar(String mnrAadhar) {
        this.mnrAadhar = mnrAadhar;
    }
    
    
}
