/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gtl.mmf.service.vo;

import java.io.Serializable;

/**
 *
 * @author 09860
 */
public class TempAdvVo implements Serializable {

    private String regNO;
    private String fname;
    private String middle_name;
    private String last_name;
    private String sebi_regno;
    private String sebi_validity;
    private String pan;
    private String dob;
    private String regEmail;

    private String raddressLine1;
    private String raddressLine2;
    private String rlandMark;
    private String rpincode;
    private String rcountry;
    private String rstate;
    private String rcity;
    private String rmobile;
    private String remail;
    private String risd;
    private String rstd;
    private String rtnumber;

    private String organization;
    private String jobTitle;
    private boolean samePermentaddr;

    private String oaddressLine1;
    private String oaddressLine2;
    private String olandMark;
    private String opincode;
    private String ocountry;
    private String ostate;
    private String ocity;
    private String omobile;
    private String oemail;
    private String oisd;
    private String ostd;
    private String otnumber;

    private String correspondenceAddress;
    private String bankName;
    private String branch;
    private String accountType;
    private String accountNumber;
    private String raccountNumber;
    private String ifscNo;
    private String micrNo;

    private String baddressLine1;
    private String baddressLine2;
    private String blandMark;
    private String bpincode;
    private String bcountry;
    private String bstate;
    private String bcity;

    private String pqualification;
    private String pinsititute;
    private String pyear;
    private String pqualificationId;

    private String squalification;
    private String sinsititute;

    private String syear;
    private String squalificationId;

    private String tqualification;
    private String tinsititute;
    private String tyear;
    private String tqualificationId;
    private boolean aggrementAccepted;

    private String resCity;
    private String offCity;
    private String bnkCity;
    private String advisorType;
    private String sebiPath;
    
    private String advPicPath;
    private String oneLineDesc;
    private String aboutMe;
    private String myInvestmentStrategy;
    private Boolean indvOrCprt;

    public String getRegNO() {
        return regNO;
    }

    public void setRegNO(String regNO) {
        this.regNO = regNO;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getMiddle_name() {
        return middle_name;
    }

    public void setMiddle_name(String middle_name) {
        this.middle_name = middle_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getSebi_regno() {
        return sebi_regno;
    }

    public void setSebi_regno(String sebi_regno) {
        this.sebi_regno = sebi_regno;
    }

    public String getSebi_validity() {
        return sebi_validity;
    }

    public void setSebi_validity(String sebi_validity) {
        this.sebi_validity = sebi_validity;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getRegEmail() {
        return regEmail;
    }

    public void setRegEmail(String regEmail) {
        this.regEmail = regEmail;
    }

    public String getRaddressLine1() {
        return raddressLine1;
    }

    public void setRaddressLine1(String raddressLine1) {
        this.raddressLine1 = raddressLine1;
    }

    public String getRaddressLine2() {
        return raddressLine2;
    }

    public void setRaddressLine2(String raddressLine2) {
        this.raddressLine2 = raddressLine2;
    }

    public String getRlandMark() {
        return rlandMark;
    }

    public void setRlandMark(String rlandMark) {
        this.rlandMark = rlandMark;
    }

    public String getRpincode() {
        return rpincode;
    }

    public void setRpincode(String rpincode) {
        this.rpincode = rpincode;
    }

    public String getRcountry() {
        return rcountry;
    }

    public void setRcountry(String rcountry) {
        this.rcountry = rcountry;
    }

    public String getRstate() {
        return rstate;
    }

    public void setRstate(String rstate) {
        this.rstate = rstate;
    }

    public String getRcity() {
        return rcity;
    }

    public void setRcity(String rcity) {
        this.rcity = rcity;
    }

    public String getRmobile() {
        return rmobile;
    }

    public void setRmobile(String rmobile) {
        this.rmobile = rmobile;
    }

    public String getRemail() {
        return remail;
    }

    public void setRemail(String remail) {
        this.remail = remail;
    }

    public String getRisd() {
        return risd;
    }

    public void setRisd(String risd) {
        this.risd = risd;
    }

    public String getRstd() {
        return rstd;
    }

    public void setRstd(String rstd) {
        this.rstd = rstd;
    }

    public String getRtnumber() {
        return rtnumber;
    }

    public void setRtnumber(String rtnumber) {
        this.rtnumber = rtnumber;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public boolean isSamePermentaddr() {
        return samePermentaddr;
    }

    public void setSamePermentaddr(boolean samePermentaddr) {
        this.samePermentaddr = samePermentaddr;
    }

    public String getOaddressLine1() {
        return oaddressLine1;
    }

    public void setOaddressLine1(String oaddressLine1) {
        this.oaddressLine1 = oaddressLine1;
    }

    public String getOaddressLine2() {
        return oaddressLine2;
    }

    public void setOaddressLine2(String oaddressLine2) {
        this.oaddressLine2 = oaddressLine2;
    }

    public String getOlandMark() {
        return olandMark;
    }

    public void setOlandMark(String olandMark) {
        this.olandMark = olandMark;
    }

    public String getOpincode() {
        return opincode;
    }

    public void setOpincode(String opincode) {
        this.opincode = opincode;
    }

    public String getOcountry() {
        return ocountry;
    }

    public void setOcountry(String ocountry) {
        this.ocountry = ocountry;
    }

    public String getOstate() {
        return ostate;
    }

    public void setOstate(String ostate) {
        this.ostate = ostate;
    }

    public String getOcity() {
        return ocity;
    }

    public void setOcity(String ocity) {
        this.ocity = ocity;
    }

    public String getOmobile() {
        return omobile;
    }

    public void setOmobile(String omobile) {
        this.omobile = omobile;
    }

    public String getOemail() {
        return oemail;
    }

    public void setOemail(String oemail) {
        this.oemail = oemail;
    }

    public String getOisd() {
        return oisd;
    }

    public void setOisd(String oisd) {
        this.oisd = oisd;
    }

    public String getOstd() {
        return ostd;
    }

    public void setOstd(String ostd) {
        this.ostd = ostd;
    }

    public String getOtnumber() {
        return otnumber;
    }

    public void setOtnumber(String otnumber) {
        this.otnumber = otnumber;
    }

    public String getCorrespondenceAddress() {
        return correspondenceAddress;
    }

    public void setCorrespondenceAddress(String correspondenceAddress) {
        this.correspondenceAddress = correspondenceAddress;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getRaccountNumber() {
        return raccountNumber;
    }

    public void setRaccountNumber(String raccountNumber) {
        this.raccountNumber = raccountNumber;
    }

    public String getIfscNo() {
        return ifscNo;
    }

    public void setIfscNo(String ifscNo) {
        this.ifscNo = ifscNo;
    }

    public String getMicrNo() {
        return micrNo;
    }

    public void setMicrNo(String micrNo) {
        this.micrNo = micrNo;
    }

    public String getBaddressLine1() {
        return baddressLine1;
    }

    public void setBaddressLine1(String baddressLine1) {
        this.baddressLine1 = baddressLine1;
    }

    public String getBaddressLine2() {
        return baddressLine2;
    }

    public void setBaddressLine2(String baddressLine2) {
        this.baddressLine2 = baddressLine2;
    }

    public String getBlandMark() {
        return blandMark;
    }

    public void setBlandMark(String blandMark) {
        this.blandMark = blandMark;
    }

    public String getBpincode() {
        return bpincode;
    }

    public void setBpincode(String bpincode) {
        this.bpincode = bpincode;
    }

    public String getBcountry() {
        return bcountry;
    }

    public void setBcountry(String bcountry) {
        this.bcountry = bcountry;
    }

    public String getBstate() {
        return bstate;
    }

    public void setBstate(String bstate) {
        this.bstate = bstate;
    }

    public String getBcity() {
        return bcity;
    }

    public void setBcity(String bcity) {
        this.bcity = bcity;
    }

    public String getPqualification() {
        return pqualification;
    }

    public void setPqualification(String pqualification) {
        this.pqualification = pqualification;
    }

    public String getPinsititute() {
        return pinsititute;
    }

    public void setPinsititute(String pinsititute) {
        this.pinsititute = pinsititute;
    }

    public String getPyear() {
        return pyear;
    }

    public void setPyear(String pyear) {
        this.pyear = pyear;
    }

    public String getPqualificationId() {
        return pqualificationId;
    }

    public void setPqualificationId(String pqualificationId) {
        this.pqualificationId = pqualificationId;
    }

    public String getSqualification() {
        return squalification;
    }

    public void setSqualification(String squalification) {
        this.squalification = squalification;
    }

    public String getSinsititute() {
        return sinsititute;
    }

    public void setSinsititute(String sinsititute) {
        this.sinsititute = sinsititute;
    }

    public String getSyear() {
        return syear;
    }

    public void setSyear(String syear) {
        this.syear = syear;
    }

    public String getSqualificationId() {
        return squalificationId;
    }

    public void setSqualificationId(String squalificationId) {
        this.squalificationId = squalificationId;
    }

    public String getTqualification() {
        return tqualification;
    }

    public void setTqualification(String tqualification) {
        this.tqualification = tqualification;
    }

    public String getTinsititute() {
        return tinsititute;
    }

    public void setTinsititute(String tinsititute) {
        this.tinsititute = tinsititute;
    }

    public String getTyear() {
        return tyear;
    }

    public void setTyear(String tyear) {
        this.tyear = tyear;
    }

    public String getTqualificationId() {
        return tqualificationId;
    }

    public void setTqualificationId(String tqualificationId) {
        this.tqualificationId = tqualificationId;
    }

    public boolean isAggrementAccepted() {
        return aggrementAccepted;
    }

    public void setAggrementAccepted(boolean aggrementAccepted) {
        this.aggrementAccepted = aggrementAccepted;
    }

    public String getResCity() {
        return resCity;
    }

    public void setResCity(String resCity) {
        this.resCity = resCity;
    }

    public String getOffCity() {
        return offCity;
    }

    public void setOffCity(String offCity) {
        this.offCity = offCity;
    }

    public String getBnkCity() {
        return bnkCity;
    }

    public void setBnkCity(String bnkCity) {
        this.bnkCity = bnkCity;
    }

    public String getAdvisorType() {
        return advisorType;
    }

    public void setAdvisorType(String advisorType) {
        this.advisorType = advisorType;
    }

    public String getSebiPath() {
        return sebiPath;
    }

    public void setSebiPath(String sebiPath) {
        this.sebiPath = sebiPath;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }
	
    public String getAdvPicPath() {
		return advPicPath;
	}

	public void setAdvPicPath(String advPicPath) {
		this.advPicPath = advPicPath;
	}

	public String getOneLineDesc() {
		return oneLineDesc;
	}

	public void setOneLineDesc(String oneLineDesc) {
		this.oneLineDesc = oneLineDesc;
	}

	public String getAboutMe() {
		return aboutMe;
	}

	public void setAboutMe(String aboutMe) {
		this.aboutMe = aboutMe;
	}

	public String getMyInvestmentStrategy() {
		return myInvestmentStrategy;
	}

	public void setMyInvestmentStrategy(String myInvestmentStrategy) {
		this.myInvestmentStrategy = myInvestmentStrategy;
	}
	
	public TempAdvVo() {
	    this.regNO = "";
	    this.fname = "";
	    this.middle_name = "";
	    this.last_name = "";
	    this.sebi_regno = "";
	    this.sebi_validity = "";
	    this.pan = "";
	    this.dob = "";
	    this.regEmail = "";
	    this.raddressLine1 = "";
	    this.raddressLine2 = "";
	    this.rlandMark = "";
	    this.rpincode = "";
	    this.rcountry = "";
	    this.rstate = "";
	    this.rcity = "";
	    this.rmobile = "";
	    this.remail = "";
	    this.risd = "";
	    this.rstd = "";
	    this.rtnumber = "";
	    this.organization = "";
	    this.jobTitle = "";
	    this.samePermentaddr = false;
	    this.oaddressLine1 = "";
	    this.oaddressLine2 = "";
	    this.olandMark = "";
	    this.opincode = "";
	    this.ocountry = "";
	    this.ostate = "";
	    this.ocity = "";
	    this.omobile = "";
	    this.oemail = "";
	    this.oisd = "";
	    this.ostd = "";
	    this.otnumber = "";
	    this.correspondenceAddress = "";
	    this.bankName = "";
	    this.branch = "";
	    this.accountType = "";
	    this.accountNumber = "";
	    this.raccountNumber = "";
	    this.ifscNo = "";
	    this.micrNo = "";
	    this.baddressLine1 = "";
	    this.baddressLine2 = "";
	    this.blandMark = "";
	    this.bpincode = "";
	    this.bcountry = "";
	    this.bstate = "";
	    this.bcity = "";
	    this.pqualification = "";
	    this.pinsititute = "";
	    this.pyear = "";
	    this.pqualificationId = "";
	    this.squalification = "";
	    this.sinsititute = "";
	    this.syear = "";
	    this.squalificationId = "";
	    this.tqualification = "";
	    this.tinsititute = "";
	    this.tyear = "";
	    this.tqualificationId = "";
	    this.aggrementAccepted = false;
	    this.resCity = "";
	    this.offCity = "";
	    this.bnkCity = "";
	    this.advisorType = "";
	    this.sebiPath = "";
	    this.advPicPath = "";
	    this.oneLineDesc = "";
	    this.aboutMe = "";
	    this.myInvestmentStrategy = "";
	}

	public Boolean getIndvOrCprt() {
		return indvOrCprt;
	}

	public void setIndvOrCprt(Boolean indvOrCprt) {
		this.indvOrCprt = indvOrCprt;
	}
}
